English Mod, with all fixes from the previous release (29/Oct/2026), plus:

## Text
- **"New" badges** are in English on every screen: library tabs and books, forge, alchemy, medicine, shop, commissions, save / load tabs and help entries (only the inventory had them before).
- **Life menu "NEW" badges** are in English too, with the word in the middle of its diamond, and so are other images that the game shows only later (evaluation grade glow, the strike-back popup in combat).
- **Two dialogue lines in English again:** one in the quest "Providing Information" and one other line were showing in Chinese.
- **Secondary objectives in combat:** the status stays in one piece after the objective ("Zhao Zilong survives" / "(Not Achieved)") instead of breaking the line after the character's name.

## Troubleshooting
- **Diagnostic log:** the mod now writes `BepInEx\EnglishPatch_Diagnostics.log` every time the game starts. It lists the Windows language, the mod files and any old copies of them in the game folder, the translation folder, the fonts, and the game controllers. Send this file with a problem report.
- **`BepInEx\LogOutput.log`** is written again, and its first lines show which build of the mod is running and whether the diagnostic log is on.
- The diagnostic log costs nothing while you play: game controllers are looked up every few seconds, and their buttons are only watched while one is plugged in.
- **Character walks on its own:** the game takes any device Windows lists as a game controller (rudder pedals, steering wheel, flight stick...) for a gamepad, and a pedal at rest can push the character forward like a held W key. Unplug the device while playing. The diagnostic log shows the controllers Windows reports.

## Settings
All settings are in `BepInEx\config\plugins.englishpatch.cfg`:
- `Font =` the font for the English texts, any font installed in Windows (for example Arial, Georgia, Palatino Linotype, Book Antiqua, Constantia).
- `CombatFont =` the font for the combat texts written in the game's own font (DFKai-SB). Leave it empty to keep the game's font. On a Windows without Chinese fonts DFKai-SB is missing, set `CombatFont = Arial` if those texts look wrong.
- `MessageFont =` **new**, the font of the messages popping up on screen (items acquired, money, party members, stats and skills increased...). Leave it empty to keep the game's font.
- `EndingFont =` **new**, the font of the ending screens. Leave it empty to use `Font`.
- `DialogueFont =` the font of the talk box text only. Leave it empty to use `Font`.
- `DialogueFontSize =` the size of the talk box text. `0` keeps the size of the other texts (20).
- `HideBuffLabelBackground =` `true` hides the dark tab behind the buff labels in combat.
- `ChristmasTitle =` the Christmas title on the main menu: `Auto` (only in December, by the PC date), `Always` or `Never`.
- `LayoutLog =` under `[Debug]`, writes `BepInEx\EnglishPatch_Layout.log`. Only useful to report a misplaced text.
- `DiagnosticLog =` **new**, under `[Debug]`, `true` writes `BepInEx\EnglishPatch_Diagnostics.log` (see Troubleshooting), `false` stops it.

A font that is not installed falls back to Arial. Symbol fonts (Wingdings, Webdings) have no letters and do not work. Restart the game after changing a setting. Updating the mod replaces this file, so set your settings again afterwards.

## Installation
1. Download `PoW_English.zip`.
2. Extract it, open the `Mod` folder, and copy everything inside it into the game folder (where `PathOfWuxia.exe` is). Replace existing files.
3. Do not keep extracted copies of the mod (a `Mod` folder, older zips) inside the game folder, so an old file cannot be copied back by mistake.
